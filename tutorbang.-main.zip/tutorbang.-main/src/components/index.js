import Nav from "./Nav";
import Hero from "./Hero";
import About from "./About";
import Course from "./Course";
import Testimony from "./Testimony";
import CTA from "./CTA";
import Footer from "./Footer";
import Stats from "./Stats";

export { Nav, Hero, About, Course, Testimony, CTA, Footer, Stats };
